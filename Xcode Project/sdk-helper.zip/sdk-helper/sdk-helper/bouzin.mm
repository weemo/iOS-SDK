//
//  bouzin.cpp
//  sdk-helper
//
//  Created by Charles Thierry on 7/18/13.
//  Copyright (c) 2013 Weemo SAS. All rights reserved.
//

#include <cstdio>
